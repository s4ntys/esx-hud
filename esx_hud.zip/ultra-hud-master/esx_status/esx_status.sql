USE `es_extended`;

ALTER TABLE `users` ADD COLUMN `status` LONGTEXT NULL;
